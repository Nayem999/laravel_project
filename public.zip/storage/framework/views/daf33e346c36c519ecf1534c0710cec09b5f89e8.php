<?php $__env->startSection('content'); ?>

<?php if($pro->cover): ?>
<img src="<?php echo e(asset('uploads/'.$pro->cover)); ?>" class="img-fluid"  style="width:100%; height:300px;" alt="Responsive image">
<?php else: ?>
<img src="<?php echo e(asset('uploads/cover.png')); ?>" class="img-fluid"  style="width:100%; height:300px;" alt="Responsive image">
<?php endif; ?>


<?php if($pro->image): ?>
<img src="<?php echo e(asset('uploads/'.$pro->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:150px;height:150px;" alt="Responsive image">
<?php else: ?>
<img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:150px;height:150px;" alt="Responsive image">
<?php endif; ?>
<br>

<?php if($pro->first_name): ?>
<div class="row p-3"> 
        <div class="col-4">
        Name:
        </div>
        <div class="col-8">
        <?php echo e($pro->first_name); ?> <?php echo e($pro->last_name); ?>

            </div>
        </div>
<?php endif; ?>


<?php if($pro->phone): ?>
<div class="row p-3"> 
        <div class="col-4">
        Phone:
        </div>
        <div class="col-8">
                <?php echo e($pro->phone); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->birth): ?>
<div class="row p-3"> 
        <div class="col-4">
        Birthday:
        </div>
        <div class="col-8">
                <?php echo e($pro->birth); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->about): ?>
<div class="row p-3"> 
        <div class="col-4">
        About me:
        </div>
        <div class="col-8">
                <?php echo e($pro->about); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->hobby): ?>
<div class="row p-3"> 
        <div class="col-4">
        Hobby:
        </div>
        <div class="col-8">
                <?php echo e($pro->hobby); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->twitter): ?>
<div class="row p-3"> 
        <div class="col-4">
        Twitter:
        </div>
        <div class="col-8">
                <?php echo e($pro->twitter); ?>

            </div>
</div>

<?php endif; ?>

<?php if($pro->li): ?>
<div class="row p-3"> 
        <div class="col-4">
        Linkin:
        </div>
        <div class="col-8">
                <?php echo e($pro->li); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->ig): ?>
<div class="row p-3"> 
        <div class="col-4">
        Instagram
        </div>
        <div class="col-8">
                <?php echo e($pro->ig); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->fiverr): ?>
<div class="row p-3"> 
        <div class="col-4">
        Fiverr
        </div>
        <div class="col-8">
                <?php echo e($pro->fiverr); ?>

            </div>
</div>
<?php endif; ?>

    <br>

                   
   <a class="btn btn-success" href="<?php echo e(url('profile/'.Auth::id()."/edit")); ?>">Update Profile</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bdnetwork\resources\views/profile/index.blade.php ENDPATH**/ ?>