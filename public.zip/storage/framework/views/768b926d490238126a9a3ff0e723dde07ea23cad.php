<?php $__env->startSection('content'); ?>

<img src="<?php echo e(asset('uploads/cover.png')); ?>" class="img-fluid" style="width:100%; height:300px;" alt="Responsive image">
<br>
<img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:150px;height:150px;" alt="Responsive image">

<br>

    <br>

                   
   <a class="btn btn-success" href="<?php echo e(url('profile/'.Auth::id()."/edit")); ?>">Update Profile</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bdnetwork\resources\views/profile/noprofile.blade.php ENDPATH**/ ?>