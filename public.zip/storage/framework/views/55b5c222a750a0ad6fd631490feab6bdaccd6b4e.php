<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.formerrors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($pro): ?>
<?php echo Form::model($pro,['route'=>['profile.update', $pro->id], 'method' => 'PATCH','enctype'=>'multipart/form-data']); ?>

<?php else: ?>
<?php echo Form::open(['url'=>'profile', 'method' => 'post','enctype'=>'multipart/form-data']); ?>

<?php endif; ?>
<?php echo Form::label('first_name','First Name',['class'=>'awesome']); ?>

<?php echo Form::text('first_name',null,['class'=>'form-control']); ?>

<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
<div class="alert alert-dark">Check your First Name</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('last_name','Last Name',['class'=>'awesome']); ?>

<?php echo Form::text('last_name',null,['class'=>'form-control']); ?>

<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
<div class="alert alert-dark">Check your Last Name</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('birth','Birth Date',['class'=>'awesome']); ?>

<?php echo Form::date('birth',null,['class'=>'form-control']); ?>

<?php if ($errors->has('birth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('birth'); ?>
<div class="alert alert-dark">Check your Birth Date</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('phone','Phone Number',['class'=>'awesome']); ?>

<?php echo Form::text('phone',null,['class'=>'form-control']); ?>

<?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
<div class="alert alert-dark">Check your Phone Number</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<br>
<?php echo Form::label('about','Gender',['class'=>'awesome']); ?> &nbsp;&nbsp;

<?php echo Form::radio('about','Male', true ); ?> Male &nbsp;
<?php echo Form::radio('about','Female', false); ?> Female
<?php if ($errors->has('about')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about'); ?>
<div class="alert alert-dark">Check your self</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
<br>
<?php echo Form::label('hobby','Hobby',['class'=>'awesome']); ?>

<?php echo Form::text('hobby',null,['class'=>'form-control']); ?>

<?php if ($errors->has('hobby')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('hobby'); ?>
<div class="alert alert-dark">Check your Hobby</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
<br>
<?php echo Form::label('cover','Cover Photo',['class'=>'awesome']); ?>

<?php echo Form::file('cover',null,['class'=>'form-control']); ?>

<?php if ($errors->has('cover')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cover'); ?>
<div class="alert alert-dark">Check Cover Photo</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<div class="form-group">
<?php echo Form::label('image','My Photo'); ?>

<?php echo Form::file('image', null, ['class' => 'form-control']); ?>

</div>
<?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
<div class="alert alert-dark">Check your My Photo</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('twitter','Twitter',['class'=>'awesome']); ?>

<?php echo Form::text('twitter',null,['class'=>'form-control']); ?>

<?php if ($errors->has('twitter')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('twitter'); ?>
<div class="alert alert-dark">Check your Twitter</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('li','Linkin',['class'=>'awesome']); ?>

<?php echo Form::text('li',null,['class'=>'form-control']); ?>

<?php if ($errors->has('li')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('li'); ?>
<div class="alert alert-dark">Check your Linkin</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('ig','Instragrame',['class'=>'awesome']); ?>

<?php echo Form::text('ig',null,['class'=>'form-control']); ?>

<?php if ($errors->has('ig')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ig'); ?>
<div class="alert alert-dark">Check your Instragrame</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('upwork','Upwork',['class'=>'awesome']); ?>

<?php echo Form::text('upwork',null,['class'=>'form-control']); ?>

<?php if ($errors->has('upwork')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('upwork'); ?>
<div class="alert alert-dark">Check your Upwork</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

<?php echo Form::label('fiverr','Fiverr',['class'=>'awesome']); ?>

<?php echo Form::text('fiverr',null,['class'=>'form-control']); ?>

<?php if ($errors->has('fiverr')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fiverr'); ?>
<div class="alert alert-dark">Check your Fiverr</div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


<br>
<?php echo Form::submit('Submit'); ?>


<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdnetwork\resources\views/profile/create.blade.php ENDPATH**/ ?>