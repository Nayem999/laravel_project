<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.formerrors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                
   <!-- Trigger the modal with a button -->
   <div class="bg-white p-2 d-flex justify-content-center">
   <button type="button" class="btn table-bordered " data-toggle="modal" data-target="#myModal">
       <input type="text" class="form-control" name="" id="" placeholder="What's is your mind?"><br>
       <input type="file" class="form-control" name="" id="">
    </button>
  </div>
   <!-- Modal -->
   <div class="modal fade" id="myModal" role="dialog">
     <div class="modal-dialog modal-lg">
       <div class="modal-content">
         <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal">&times;</button>
            
         </div>
         <div class="modal-body">
           
           <?php echo Form::open(['url'=>'post','method'=>'post','enctype'=>'multipart/form-data']); ?>

           <?php echo Form::label('title', 'Post', ['class'=>'awesome']); ?>

           <?php echo Form::text('title','', ['rol'=>'3','col'=>'10', 'class'=>'form-control']); ?>

           <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
           <div class="alert alert-dark">Check your post</div>
           <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
           <br>
           <?php echo Form::label('privacy','Privacy'); ?>

            <?php echo Form::select('privacy', ['1'=>'Public','2'=>'Friends','3'=>'Onlyme'], null,
            array('class'=>'form-control')); ?>

            <?php if ($errors->has('privacy')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('privacy'); ?>
            <div class="alert alert-dark">Check your privacy</div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <br>
           <div class="form-group">
            <?php echo Form::label('photo','Photo'); ?>

            <?php echo Form::file('photo', null, ['class' => 'form-control']); ?>

            </div>
            <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
            <div class="alert alert-dark">Check your Photo</div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <br>
            <?php echo Form::submit('Submit'); ?>

           <?php echo Form::Close(); ?>

         </div>
         <div class="modal-footer">
           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
         </div>
       </div>
     </div>
   </div>
<br>

   <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="p-2">
   <div class="bg-white p-2">
<div class="row">
  <div class="col-1">
      <?php $__empty_1 = true; $__currentLoopData = $post->profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
           <?php if($p->image): ?>
      <img src="<?php echo e(asset('uploads/'.$p->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
      <?php endif; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
      <?php endif; ?>
  </div>
  <div class="col-11">
      <?php $__empty_1 = true; $__currentLoopData = $post->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php echo e($p->name); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      no name
      <?php endif; ?>
<br>

Post Created At: <?php echo e($post->created_at->diffForHumans()); ?>

  </div>
</div>
<hr>
<br>
<?php if($post->title): ?>
<?php echo e($post->title); ?>

<?php endif; ?>
<br><br>
<?php if($post->photo): ?>
<img src="<?php echo e(asset('uploads/'.$post->photo)); ?>" class="img-fluid "  style="width:100%; height:300px;" alt="Responsive image">
<?php endif; ?>
<br>
<div class="row p-3">
  <div class="col-6 border btn border-success d-flex justify-content-center">
  <button type="button" class="btn btn-success btn-circle">
<?php echo e(count($post->reaction->where('reaction',1))); ?>

</button>
  <?php echo Form::open(['route'=>'photolike', 'method' => 'post']); ?>

<?php echo Form::hidden('id',$post->id); ?>

<?php echo Form::submit('Like'); ?> 
<?php echo Form::close(); ?> 
</div>
  <div class="col-6 border btn border-success d-flex justify-content-center">
  <button type="button" class="btn btn-danger btn-circle">
    <?php echo e(count($post->reaction->where('reaction',0))); ?>

  </button>
  <?php echo Form::open(['route'=>'photodislike', 'method' => 'post']); ?>

<?php echo Form::hidden('id',$post->id); ?>

<?php echo Form::submit('Dislike'); ?>   
<?php echo Form::close(); ?> 
</div>
</div>


<?php echo Form::open(['url'=>'comment', 'method' => 'post']); ?>

<?php echo Form::hidden('id',$post->id); ?>

<?php echo Form::textarea('comment',null,['class'=>'form-control mr-3 mt-3','rows'=>1,'style'=>'border-radius: 12px']); ?>

<br>
<?php echo Form::submit('Comment',['class'=>'form-control d-flex justify-content-center']); ?>

<?php echo Form::close(); ?>


<div style="max-height:200px;overflow:auto;">
    <?php $__empty_1 = true; $__currentLoopData = $com->where('post_id',$post->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="row">
    <div class="col-3">
    <?php $__empty_2 = true; $__currentLoopData = $all->where('id',$c->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
  <p> <?php echo e($f->name); ?></p>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
  <?php endif; ?>
  </div>
  <div class="col-9">
  <p> <?php echo e($c->body); ?> <br><?php echo e($c->created_at->diffForHumans()); ?></p>
  </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <?php endif; ?>
</div>

</div>
</div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdnetwork\resources\views/home.blade.php ENDPATH**/ ?>