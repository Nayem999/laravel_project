<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.formerrors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                

   <!-- Trigger the modal with a button -->
   <button type="button" class="btn table-bordered btn-sm" data-toggle="modal" data-target="#myModal">
       <input type="text" class="form-control" name="" id="" placeholder="What's is your mind?"><br>
       <input type="file" class="form-control" name="" id="">
    </button>
 
   <!-- Modal -->
   <div class="modal fade" id="myModal" role="dialog">
     <div class="modal-dialog modal-lg">
       <div class="modal-content">
         <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal">&times;</button>
           
          
         </div>
         <div class="modal-body">

           
           <?php echo Form::open(['url'=>'post','method'=>'post','enctype'=>'multipart/form-data']); ?>



           <?php echo Form::label('title', 'Post', ['class'=>'awesome']); ?>

           <?php echo Form::text('title','', ['rol'=>'3','col'=>'10', 'class'=>'form-control']); ?>

           <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
           <div class="alert alert-dark">Check your post</div>
           <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
           <br>
           <?php echo Form::label('privacy','Privacy'); ?>

            <?php echo Form::select('privacy', ['1'=>'Public','2'=>'Friends','3'=>'Onlyme'], null,
            array('class'=>'form-control')); ?>

            <?php if ($errors->has('privacy')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('privacy'); ?>
            <div class="alert alert-dark">Check your privacy</div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <br>
           <div class="form-group">
            <?php echo Form::label('photo','Photo'); ?>

            <?php echo Form::file('photo', null, ['class' => 'form-control']); ?>

            </div>
            <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
            <div class="alert alert-dark">Check your Photo</div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <br>
            <?php echo Form::submit('Submit'); ?>

           <?php echo Form::Close(); ?>

         </div>
         <div class="modal-footer">
           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
         </div>
       </div>
     </div>

   </div>

<br>
   <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h6><?php echo e($post->name); ?></h6>


<br>
<?php
$idd=$post->user_id;
$idp=$pro->user_id;

?>

<?php if($idp = $idd): ?>

<img src="<?php echo e(asset('uploads/'.$pro->photo)); ?>" class="img-fluid "  style="width:100%; height:300px;" alt="Responsive image">

<?php endif; ?>



<br>
<?php if($post->title): ?>
<?php echo e($post->title); ?>

<?php endif; ?>
<br>
<?php if($post->photo): ?>
<img src="<?php echo e(asset('uploads/'.$post->photo)); ?>" class="img-fluid "  style="width:100%; height:300px;" alt="Responsive image">
<?php endif; ?>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bdnetwork\resources\views/home.blade.php ENDPATH**/ ?>