<?php $__env->startSection('content'); ?>
<div>
        <?php $__empty_1 = true; $__currentLoopData = $add->where('user_id',Auth::id())->where('action',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="p-2">
                <div class="bg-white p-2">
                    <div class="row">
                            <div class="col-2">
        <?php $__empty_2 = true; $__currentLoopData = $user->where('id',$f->add_friend); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
              <?php $__empty_3 = true; $__currentLoopData = $profile->where('user_id',$f->add_friend); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
              <img src="<?php echo e(asset('uploads/'.$image->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
              <img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
              <?php endif; ?>
                            </div>
                            <div class="col-10">
<a href="<?php echo e(url('friend/'.$name->id)); ?>" class="text-secondary"><h4 class="p-2"> <?php echo e($name->name); ?></h4></a><br>
                            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
        <?php endif; ?>
    </div>
</div>
</div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <?php endif; ?>


<br>
   <?php $__empty_1 = true; $__currentLoopData = $add->where('add_friend',Auth::id())->where('action',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <div class="p-2">
        <div class="bg-white p-2">
            <div class="row">
                    <div class="col-2">
   <?php $__empty_2 = true; $__currentLoopData = $user->where('id',$f->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
         <?php $__empty_3 = true; $__currentLoopData = $profile->where('user_id',$f->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
         <img src="<?php echo e(asset('uploads/'.$image->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
         <img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
         <?php endif; ?>
        </div>
        <div class="col-10">
         <a href="<?php echo e(url('friend/'.$name->id)); ?>" class="text-secondary"> <h4 class="p-2"><?php echo e($name->name); ?></h4></a><br>
        </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
   <?php endif; ?>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdnetwork\resources\views/friend/myfriend.blade.php ENDPATH**/ ?>