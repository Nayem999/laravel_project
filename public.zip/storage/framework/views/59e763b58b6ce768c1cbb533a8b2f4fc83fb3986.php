<?php $__env->startSection('content'); ?>

<div>

<?php $__empty_1 = true; $__currentLoopData = $m; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<div class="p-2">
        <div class="bg-white p-2">
            <div class="row">
                <div class="col-2">
                        <?php $__empty_2 = true; $__currentLoopData = $i->where('user_id',$all->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <img src="<?php echo e(asset('uploads/'.$f->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:40px;height:40px;" alt="Responsive image">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:40px;height:40px;" alt="Responsive image">
                        <?php endif; ?>
                </div>
                <div class="col-6">
                   
                   <?php $__empty_2 = true; $__currentLoopData = $k->where('id',$all->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                   <h4 class="p-2"><?php echo e($user->name); ?></h4>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                      <?php endif; ?>
                </div>
                <div class="col-2">
                        <?php echo Form::open(['url'=>'friend/'.$all->id, 'method' => 'put']); ?>

                        
                        <?php echo Form::submit('Add Friend',['class'=>'btn btn-success']); ?>   
                        <?php echo Form::close(); ?> 
                </div>
                <div class="col-2">
                        <?php echo Form::open(['url'=>'friend/'.$all->id, 'method' => 'delete']); ?>

                        
                        <?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>   
                        <?php echo Form::close(); ?> 
                </div>
            </div>
        </div>
</div>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    
<?php endif; ?>


</div>

                   


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdnetwork\resources\views/friend/wait.blade.php ENDPATH**/ ?>