<?php $__env->startSection('content'); ?>


<div class="relative">
                <?php if($pro->cover): ?>
                <img src="<?php echo e(asset('uploads/'.$pro->cover)); ?>" class="img-fluid"  style="width:100%; height:300px;" alt="Responsive image">
                <?php else: ?>
                <img src="<?php echo e(asset('uploads/cover.png')); ?>" class="img-fluid"  style="width:100%; height:300px;" alt="Responsive image">
                <?php endif; ?>
                <div class="absolute">
          <?php if($pro->image): ?>
          <img src="<?php echo e(asset('uploads/'.$pro->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:150px;height:150px;" alt="Responsive image">
          <?php else: ?>
          <img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:150px;height:150px;" alt="Responsive image">
          <?php endif; ?>        
                </div>
              </div>






<br>
<hr>
<?php if($pro->first_name): ?>
<div class="row p-3"> 
        <div class="col-4">
        Name:
        </div>
        <div class="col-8">
        <?php echo e($pro->first_name); ?> 
        <?php if($pro->last_name): ?>
        <?php echo e($pro->last_name); ?>

        <?php endif; ?>
            </div>
        </div>

        <?php else: ?>
        <div class="row p-3"> 
                <div class="col-4">
                Name:
                </div>
                <div class="col-8">
                    <?php echo e($view->name); ?>

                </div>
        </div>

<?php endif; ?>


<?php if($pro->phone): ?>
<div class="row p-3"> 
        <div class="col-4">
        Phone:
        </div>
        <div class="col-8">
                <?php echo e($pro->phone); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->birth): ?>
<div class="row p-3"> 
        <div class="col-4">
        Birthday:
        </div>
        <div class="col-8">
                <?php echo e($pro->birth); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->about): ?>
<div class="row p-3"> 
        <div class="col-4">
        Gender:
        </div>
        <div class="col-8">
                <?php echo e($pro->about); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->hobby): ?>
<div class="row p-3"> 
        <div class="col-4">
        Hobby:
        </div>
        <div class="col-8">
                <?php echo e($pro->hobby); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->twitter): ?>
<div class="row p-3"> 
        <div class="col-4">
        Twitter:
        </div>
        <div class="col-8">
                <?php echo e($pro->twitter); ?>

            </div>
</div>

<?php endif; ?>

<?php if($pro->li): ?>
<div class="row p-3"> 
        <div class="col-4">
        Linkin:
        </div>
        <div class="col-8">
                <?php echo e($pro->li); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->ig): ?>
<div class="row p-3"> 
        <div class="col-4">
        Instagram
        </div>
        <div class="col-8">
                <?php echo e($pro->ig); ?>

            </div>
</div>
<?php endif; ?>


<?php if($pro->fiverr): ?>
<div class="row p-3"> 
        <div class="col-4">
        Fiverr
        </div>
        <div class="col-8">
                <?php echo e($pro->fiverr); ?>

            </div>
</div>
<?php endif; ?>

    <br>

                   


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdnetwork\resources\views/friend/detail.blade.php ENDPATH**/ ?>