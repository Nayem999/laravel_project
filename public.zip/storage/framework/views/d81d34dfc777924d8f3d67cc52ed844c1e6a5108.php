<div class="container">
    Messager
<div class="panel panel-info"></div>
<div class="panel-heading">
<div class="panel-body">

    <?php $__empty_1 = true; $__currentLoopData = $add->where('user_id',Auth::id())->where('action',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php $__empty_2 = true; $__currentLoopData = $user->where('id',$f->add_friend); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                <?php $__empty_3 = true; $__currentLoopData = $profile->where('user_id',$f->add_friend); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                <img src="<?php echo e(asset('uploads/'.$image->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                <img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
                <?php endif; ?>
<a href="<?php echo e(url('message/'.$name->id)); ?>" class="text-secondary"> <?php echo e($name->name); ?></a><br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
          <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
     <?php endif; ?>
<br>
     <?php $__empty_1 = true; $__currentLoopData = $add->where('add_friend',Auth::id())->where('action',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
     <?php $__empty_2 = true; $__currentLoopData = $user->where('id',$f->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
           <?php $__empty_3 = true; $__currentLoopData = $profile->where('user_id',$f->user_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
           <img src="<?php echo e(asset('uploads/'.$image->image)); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
           <img src="<?php echo e(asset('uploads/profile.jpg')); ?>" class="mr-3 mt-3 rounded-circle" style="width:32px;height:32px;" alt="Responsive image">
           <?php endif; ?>
           <a href="<?php echo e(url('message/'.$name->id)); ?>" class="text-secondary"> <?php echo e($name->name); ?></a><br>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
     <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>

</div>
</div>
</div>
</div><?php /**PATH D:\xampp\htdocs\bdnetwork\resources\views/layouts/list.blade.php ENDPATH**/ ?>