<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- <title><?php echo e(config('app.name', 'Laravel')); ?></title> -->
    <title>BD Network</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('swiper/package/css/swiper.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/fontawesome.min.css')); ?>">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
    html, body {
      position: relative;
      height: 100%;
    }
    body {
      background: #eee;
      font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
      font-size: 14px;
      color:#000;
      margin: 0;
      padding: 0;
    }
    .swiper-container {
      width: 85%;
      height: 100%;
    }
    .swiper-slide {
      text-align: center;
      font-size: 18px;
      background: #fff;
      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;
    }
    .btn-circle {
    width: 30px;
    height: 30px;
    padding: 6px 0px;
    border-radius: 15px;
    text-align: center;
    font-size: 12px;
    line-height: 1.42857;
}
  </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top" id="mainNav">
    <div class="container">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
          <a class="btn text-white justify-content-start" href="<?php echo e(url('/home')); ?>">BD Network</a>
        <ul class="navbar-nav ml-auto">
        
          <?php if(auth()->guard()->guest()): ?>
         <li class="nav-item">
          <a class="nav-link text-white" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
      </li>
        <?php if(Route::has('register')): ?>
        <li class="nav-item">
         <a class="nav-link text-white" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
           </li>
         <?php endif; ?>
        <?php else: ?>
        <li class="nav-item">
          <a class="nav-link text-white" href="<?php echo e(url('profile')); ?>">
            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
             </a>
          </li>
        <li class="nav-item">
   <a class="nav-link text-white" href="<?php echo e(url('home')); ?>">Home</a>
     </li>
           
       <li class="nav-item dropdown">
         <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
         <span class="caret"></span>
          </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
         <a class="dropdown-item" href="<?php echo e(url('profile')); ?>">
           <?php echo e('Profile'); ?>

           </a>
           <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
           <?php echo e(__('Logout')); ?>

           </a>
       <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
         <?php echo csrf_field(); ?>
          </form>
            </div>
         </li>
         <?php endif; ?>
            </ul>
      </div>
    </div>
  </nav>
<br>
          <main class="py-4">
              <?php if(auth()->guard()->guest()): ?>
              <?php else: ?>
              <div class="container-fluid">

                  <div class="row justify-content-center">
                      <div class="col-md-2">
                          <div class="p-3">
                          Profile <br>
                          <i class="fas fa-facebook-messenger"> Messenger</i><br>
                          <i class="fas fa-user-friends">Add Friend</i><br>
                      </div>
                      </div>
                      <div class="col-md-7">
                              <div class="p-3">
                <?php endif; ?>      
                 <?php echo $__env->yieldContent('content'); ?>
                 <?php if(auth()->guard()->guest()): ?>
                 <?php else: ?>
                              </div>
                          </div>
                          <div class="col-md-3">
                                  <div class="p-3">
                                  Messager
                          </div>
                              </div>
                  </div>
              
              </div>
              <?php endif; ?> 
        </main>
        <script src="<?php echo e(asset('swiper/package/js/swiper.min.js')); ?>"></script>
        <script>
    var swiper = new Swiper('.swiper-container', {
      slidesPerView: 1,
      spaceBetween: 2,
      // init: false,
      slidesPerView: 'auto',
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      breakpoints: {
        640: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 4,
          spaceBetween: 40,
        },
        1024: {
          slidesPerView: 5,
          spaceBetween: 50,
        },
      }
    });
  </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\bdnetwork\resources\views/layouts/master.blade.php ENDPATH**/ ?>