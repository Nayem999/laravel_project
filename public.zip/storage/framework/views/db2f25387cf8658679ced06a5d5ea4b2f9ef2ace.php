<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.formerrors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<div>
<div class="text-light bg-dark" style="position:fixed;"> &nbsp; Friend Name: <?php echo e($user->name); ?>  &nbsp; </div><br><br>
<?php $__empty_1 = true; $__currentLoopData = $mes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php if($mes->user_id == Auth::id()): ?>
<div class="d-flex justify-content-start text-success"><?php echo e($mes->body); ?><br></div>
<?php else: ?>
<div class="d-flex justify-content-end text-danger"><?php echo e($mes->body); ?><br></div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    
<?php endif; ?>
</div>
<div class="fixed-bottom d-flex justify-content-center">

<?php echo Form::open(['url'=>'message', 'method' => 'post']); ?>

<?php echo Form::hidden('id',$id); ?>

 <?php echo Form::textarea('message',null,['class'=>'form-control mr-3 mt-3','rows'=>1 ,'style'=>'border-radius: 12px']); ?>

 <br>
 <?php echo Form::submit('Message',['class'=>'form-control d-flex justify-content-center','style'=>'border-radius: 12px']); ?>

 <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bdnetwork\resources\views/message/index.blade.php ENDPATH**/ ?>