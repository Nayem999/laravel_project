@if (session('mes'))
<div class="alert alert-success">
    {{session('mes')}}
</div>

@endif